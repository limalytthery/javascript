# js-consumindo-dados-api
Repositório do treinamento "JavaScript: Consumindo e tratando dados de uma API" da Alura Cursos Online.
